﻿using System;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.Common;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

class Program
{
    static void Main()
    {
        var nativeSettings = new NativeWindowSettings()
        {
            Size = new Vector2i(800, 600),
            Title = "Rotated Square"
        };

        using (var window = new SquareWindow(GameWindowSettings.Default, nativeSettings))
        {
            window.Run();
        }
    }
}

class SquareWindow : GameWindow
{
    int _vao, _vbo, _ebo, _shader;
    float[] _vertices =
    {
        -0.5f, -0.5f, 0f,
         0.5f, -0.5f, 0f,
         0.5f,  0.5f, 0f,
        -0.5f,  0.5f, 0f,
    };

    uint[] _indices =
    {
        0, 1, 2,
        0, 2, 3
    };

    string _vertexShaderSrc = @"
    #version 330 core
    layout(location = 0) in vec3 aPos;
    uniform mat4 transform;
    void main()
    {
        gl_Position = transform * vec4(aPos, 1.0);
    }";

    string _fragmentShaderSrc = @"
    #version 330 core
    out vec4 FragColor;
    void main()
    {
        FragColor = vec4(0.0, 0.0, 1.0, 1.0); // solid blue
    }";

    float _currentAngle = 0f;
    bool _rotationDone = false;

    public SquareWindow(GameWindowSettings gws, NativeWindowSettings nws) : base(gws, nws) { }

    protected override void OnLoad()
    {
        base.OnLoad();
        GL.ClearColor(0.2f, 0.3f, 0.3f, 1f);

        _vao = GL.GenVertexArray();
        _vbo = GL.GenBuffer();
        _ebo = GL.GenBuffer();

        GL.BindVertexArray(_vao);
        GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
        GL.BufferData(BufferTarget.ArrayBuffer, _vertices.Length * sizeof(float), _vertices, BufferUsageHint.StaticDraw);
        GL.BindBuffer(BufferTarget.ElementArrayBuffer, _ebo);
        GL.BufferData(BufferTarget.ElementArrayBuffer, _indices.Length * sizeof(uint), _indices, BufferUsageHint.StaticDraw);
        GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
        GL.EnableVertexAttribArray(0);

        int vertexShader = GL.CreateShader(ShaderType.VertexShader);

        GL.ShaderSource(vertexShader, _vertexShaderSrc);
        GL.CompileShader(vertexShader);

        int fragmentShader = GL.CreateShader(ShaderType.FragmentShader);

        GL.ShaderSource(fragmentShader, _fragmentShaderSrc);
        GL.CompileShader(fragmentShader);

        _shader = GL.CreateProgram();

        GL.AttachShader(_shader, vertexShader);
        GL.AttachShader(_shader, fragmentShader);
        GL.LinkProgram(_shader);
        GL.DeleteShader(vertexShader);
        GL.DeleteShader(fragmentShader);
    }

    protected override void OnUpdateFrame(FrameEventArgs e)
    {
        base.OnUpdateFrame(e);

        if (!_rotationDone)
        {
            _currentAngle += 45f * (float)e.Time;
            if (_currentAngle >= 45f)
            {
                _currentAngle = 45f;
                _rotationDone = true;
            }
        }
    }

    protected override void OnRenderFrame(FrameEventArgs e)
    {
        base.OnRenderFrame(e);

        GL.Clear(ClearBufferMask.ColorBufferBit);
        GL.UseProgram(_shader);

        Matrix4 transform = Matrix4.CreateRotationZ(MathHelper.DegreesToRadians(_currentAngle));
        int loc = GL.GetUniformLocation(_shader, "transform");

        GL.UniformMatrix4(loc, false, ref transform);
        GL.BindVertexArray(_vao);
        GL.DrawElements(PrimitiveType.Triangles, _indices.Length, DrawElementsType.UnsignedInt, 0);

        SwapBuffers();
    }
}
